/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define XSHUT_B_TRIS                 TRISAbits.TRISA0
#define XSHUT_B_LAT                  LATAbits.LATA0
#define XSHUT_B_PORT                 PORTAbits.RA0
#define XSHUT_B_WPU                  WPUAbits.WPUA0
#define XSHUT_B_OD                   ODCONAbits.ODCA0
#define XSHUT_B_ANS                  ANSELAbits.ANSELA0
#define XSHUT_B_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define XSHUT_B_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define XSHUT_B_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define XSHUT_B_GetValue()           PORTAbits.RA0
#define XSHUT_B_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define XSHUT_B_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define XSHUT_B_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define XSHUT_B_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define XSHUT_B_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define XSHUT_B_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define XSHUT_B_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define XSHUT_B_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA4 aliases
#define XSHUT_A_TRIS                 TRISAbits.TRISA4
#define XSHUT_A_LAT                  LATAbits.LATA4
#define XSHUT_A_PORT                 PORTAbits.RA4
#define XSHUT_A_WPU                  WPUAbits.WPUA4
#define XSHUT_A_OD                   ODCONAbits.ODCA4
#define XSHUT_A_ANS                  ANSELAbits.ANSELA4
#define XSHUT_A_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define XSHUT_A_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define XSHUT_A_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define XSHUT_A_GetValue()           PORTAbits.RA4
#define XSHUT_A_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define XSHUT_A_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define XSHUT_A_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define XSHUT_A_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define XSHUT_A_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define XSHUT_A_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define XSHUT_A_SetAnalogMode()      do { ANSELAbits.ANSELA4 = 1; } while(0)
#define XSHUT_A_SetDigitalMode()     do { ANSELAbits.ANSELA4 = 0; } while(0)

// get/set RB4 aliases
#define IO_RB4_TRIS                 TRISBbits.TRISB4
#define IO_RB4_LAT                  LATBbits.LATB4
#define IO_RB4_PORT                 PORTBbits.RB4
#define IO_RB4_WPU                  WPUBbits.WPUB4
#define IO_RB4_OD                   ODCONBbits.ODCB4
#define IO_RB4_ANS                  ANSELBbits.ANSELB4
#define IO_RB4_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define IO_RB4_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define IO_RB4_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define IO_RB4_GetValue()           PORTBbits.RB4
#define IO_RB4_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define IO_RB4_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define IO_RB4_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define IO_RB4_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define IO_RB4_SetPushPull()        do { ODCONBbits.ODCB4 = 0; } while(0)
#define IO_RB4_SetOpenDrain()       do { ODCONBbits.ODCB4 = 1; } while(0)
#define IO_RB4_SetAnalogMode()      do { ANSELBbits.ANSELB4 = 1; } while(0)
#define IO_RB4_SetDigitalMode()     do { ANSELBbits.ANSELB4 = 0; } while(0)

// get/set RB5 aliases
#define IO_RB5_TRIS                 TRISBbits.TRISB5
#define IO_RB5_LAT                  LATBbits.LATB5
#define IO_RB5_PORT                 PORTBbits.RB5
#define IO_RB5_WPU                  WPUBbits.WPUB5
#define IO_RB5_OD                   ODCONBbits.ODCB5
#define IO_RB5_ANS                  ANSELBbits.ANSELB5
#define IO_RB5_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define IO_RB5_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define IO_RB5_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define IO_RB5_GetValue()           PORTBbits.RB5
#define IO_RB5_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define IO_RB5_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define IO_RB5_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define IO_RB5_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define IO_RB5_SetPushPull()        do { ODCONBbits.ODCB5 = 0; } while(0)
#define IO_RB5_SetOpenDrain()       do { ODCONBbits.ODCB5 = 1; } while(0)
#define IO_RB5_SetAnalogMode()      do { ANSELBbits.ANSELB5 = 1; } while(0)
#define IO_RB5_SetDigitalMode()     do { ANSELBbits.ANSELB5 = 0; } while(0)

// get/set RB6 aliases
#define IO_RB6_TRIS                 TRISBbits.TRISB6
#define IO_RB6_LAT                  LATBbits.LATB6
#define IO_RB6_PORT                 PORTBbits.RB6
#define IO_RB6_WPU                  WPUBbits.WPUB6
#define IO_RB6_OD                   ODCONBbits.ODCB6
#define IO_RB6_ANS                  ANSELBbits.ANSELB6
#define IO_RB6_SetHigh()            do { LATBbits.LATB6 = 1; } while(0)
#define IO_RB6_SetLow()             do { LATBbits.LATB6 = 0; } while(0)
#define IO_RB6_Toggle()             do { LATBbits.LATB6 = ~LATBbits.LATB6; } while(0)
#define IO_RB6_GetValue()           PORTBbits.RB6
#define IO_RB6_SetDigitalInput()    do { TRISBbits.TRISB6 = 1; } while(0)
#define IO_RB6_SetDigitalOutput()   do { TRISBbits.TRISB6 = 0; } while(0)
#define IO_RB6_SetPullup()          do { WPUBbits.WPUB6 = 1; } while(0)
#define IO_RB6_ResetPullup()        do { WPUBbits.WPUB6 = 0; } while(0)
#define IO_RB6_SetPushPull()        do { ODCONBbits.ODCB6 = 0; } while(0)
#define IO_RB6_SetOpenDrain()       do { ODCONBbits.ODCB6 = 1; } while(0)
#define IO_RB6_SetAnalogMode()      do { ANSELBbits.ANSELB6 = 1; } while(0)
#define IO_RB6_SetDigitalMode()     do { ANSELBbits.ANSELB6 = 0; } while(0)

// get/set RB7 aliases
#define IO_RB7_TRIS                 TRISBbits.TRISB7
#define IO_RB7_LAT                  LATBbits.LATB7
#define IO_RB7_PORT                 PORTBbits.RB7
#define IO_RB7_WPU                  WPUBbits.WPUB7
#define IO_RB7_OD                   ODCONBbits.ODCB7
#define IO_RB7_ANS                  ANSELBbits.ANSELB7
#define IO_RB7_SetHigh()            do { LATBbits.LATB7 = 1; } while(0)
#define IO_RB7_SetLow()             do { LATBbits.LATB7 = 0; } while(0)
#define IO_RB7_Toggle()             do { LATBbits.LATB7 = ~LATBbits.LATB7; } while(0)
#define IO_RB7_GetValue()           PORTBbits.RB7
#define IO_RB7_SetDigitalInput()    do { TRISBbits.TRISB7 = 1; } while(0)
#define IO_RB7_SetDigitalOutput()   do { TRISBbits.TRISB7 = 0; } while(0)
#define IO_RB7_SetPullup()          do { WPUBbits.WPUB7 = 1; } while(0)
#define IO_RB7_ResetPullup()        do { WPUBbits.WPUB7 = 0; } while(0)
#define IO_RB7_SetPushPull()        do { ODCONBbits.ODCB7 = 0; } while(0)
#define IO_RB7_SetOpenDrain()       do { ODCONBbits.ODCB7 = 1; } while(0)
#define IO_RB7_SetAnalogMode()      do { ANSELBbits.ANSELB7 = 1; } while(0)
#define IO_RB7_SetDigitalMode()     do { ANSELBbits.ANSELB7 = 0; } while(0)

// get/set RC0 aliases
#define LCD_RS_TRIS                 TRISCbits.TRISC0
#define LCD_RS_LAT                  LATCbits.LATC0
#define LCD_RS_PORT                 PORTCbits.RC0
#define LCD_RS_WPU                  WPUCbits.WPUC0
#define LCD_RS_OD                   ODCONCbits.ODCC0
#define LCD_RS_ANS                  ANSELCbits.ANSELC0
#define LCD_RS_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define LCD_RS_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define LCD_RS_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define LCD_RS_GetValue()           PORTCbits.RC0
#define LCD_RS_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define LCD_RS_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define LCD_RS_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define LCD_RS_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define LCD_RS_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define LCD_RS_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define LCD_RS_SetAnalogMode()      do { ANSELCbits.ANSELC0 = 1; } while(0)
#define LCD_RS_SetDigitalMode()     do { ANSELCbits.ANSELC0 = 0; } while(0)

// get/set RC1 aliases
#define LCD_E_TRIS                 TRISCbits.TRISC1
#define LCD_E_LAT                  LATCbits.LATC1
#define LCD_E_PORT                 PORTCbits.RC1
#define LCD_E_WPU                  WPUCbits.WPUC1
#define LCD_E_OD                   ODCONCbits.ODCC1
#define LCD_E_ANS                  ANSELCbits.ANSELC1
#define LCD_E_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define LCD_E_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define LCD_E_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define LCD_E_GetValue()           PORTCbits.RC1
#define LCD_E_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define LCD_E_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define LCD_E_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define LCD_E_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define LCD_E_SetPushPull()        do { ODCONCbits.ODCC1 = 0; } while(0)
#define LCD_E_SetOpenDrain()       do { ODCONCbits.ODCC1 = 1; } while(0)
#define LCD_E_SetAnalogMode()      do { ANSELCbits.ANSELC1 = 1; } while(0)
#define LCD_E_SetDigitalMode()     do { ANSELCbits.ANSELC1 = 0; } while(0)

// get/set RC2 aliases
#define LCD_D4_TRIS                 TRISCbits.TRISC2
#define LCD_D4_LAT                  LATCbits.LATC2
#define LCD_D4_PORT                 PORTCbits.RC2
#define LCD_D4_WPU                  WPUCbits.WPUC2
#define LCD_D4_OD                   ODCONCbits.ODCC2
#define LCD_D4_ANS                  ANSELCbits.ANSELC2
#define LCD_D4_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define LCD_D4_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define LCD_D4_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define LCD_D4_GetValue()           PORTCbits.RC2
#define LCD_D4_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define LCD_D4_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define LCD_D4_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define LCD_D4_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define LCD_D4_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define LCD_D4_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define LCD_D4_SetAnalogMode()      do { ANSELCbits.ANSELC2 = 1; } while(0)
#define LCD_D4_SetDigitalMode()     do { ANSELCbits.ANSELC2 = 0; } while(0)

// get/set RC3 aliases
#define LCD_D5_TRIS                 TRISCbits.TRISC3
#define LCD_D5_LAT                  LATCbits.LATC3
#define LCD_D5_PORT                 PORTCbits.RC3
#define LCD_D5_WPU                  WPUCbits.WPUC3
#define LCD_D5_OD                   ODCONCbits.ODCC3
#define LCD_D5_ANS                  ANSELCbits.ANSELC3
#define LCD_D5_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define LCD_D5_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define LCD_D5_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define LCD_D5_GetValue()           PORTCbits.RC3
#define LCD_D5_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define LCD_D5_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define LCD_D5_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define LCD_D5_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define LCD_D5_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define LCD_D5_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define LCD_D5_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define LCD_D5_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

// get/set RC4 aliases
#define LCD_D6_TRIS                 TRISCbits.TRISC4
#define LCD_D6_LAT                  LATCbits.LATC4
#define LCD_D6_PORT                 PORTCbits.RC4
#define LCD_D6_WPU                  WPUCbits.WPUC4
#define LCD_D6_OD                   ODCONCbits.ODCC4
#define LCD_D6_ANS                  ANSELCbits.ANSELC4
#define LCD_D6_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define LCD_D6_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define LCD_D6_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define LCD_D6_GetValue()           PORTCbits.RC4
#define LCD_D6_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define LCD_D6_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define LCD_D6_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define LCD_D6_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define LCD_D6_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define LCD_D6_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define LCD_D6_SetAnalogMode()      do { ANSELCbits.ANSELC4 = 1; } while(0)
#define LCD_D6_SetDigitalMode()     do { ANSELCbits.ANSELC4 = 0; } while(0)

// get/set RC5 aliases
#define LCD_D7_TRIS                 TRISCbits.TRISC5
#define LCD_D7_LAT                  LATCbits.LATC5
#define LCD_D7_PORT                 PORTCbits.RC5
#define LCD_D7_WPU                  WPUCbits.WPUC5
#define LCD_D7_OD                   ODCONCbits.ODCC5
#define LCD_D7_ANS                  ANSELCbits.ANSELC5
#define LCD_D7_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define LCD_D7_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define LCD_D7_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define LCD_D7_GetValue()           PORTCbits.RC5
#define LCD_D7_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define LCD_D7_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define LCD_D7_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define LCD_D7_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define LCD_D7_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define LCD_D7_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define LCD_D7_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define LCD_D7_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/