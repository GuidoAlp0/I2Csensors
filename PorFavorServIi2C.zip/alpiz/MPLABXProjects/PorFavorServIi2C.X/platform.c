 #include "platform.h"
#include "mcc_generated_files/i2c_host/i2c1.h"
#include <xc.h>
#include <stdint.h>

#define _XTAL_FREQ 64000000UL

static void I2C_WaitDone(void)
{
    uint32_t timeout = 200000;

    while(I2C1_IsBusy() && timeout--)
    {
        I2C1_Host.Tasks();
    }
}

uint8_t VL53L4CD_RdByte(Dev_t dev, uint16_t RegisterAdress, uint8_t *value)
{
    uint8_t reg[2];

    reg[0] = (uint8_t)(RegisterAdress >> 8);
    reg[1] = (uint8_t)(RegisterAdress & 0xFF);

    if(!I2C1_WriteRead(dev, reg, 2, value, 1))
        return 1;

    I2C_WaitDone();

    return (I2C1_ErrorGet() == I2C_ERROR_NONE) ? 0 : 1;
}

uint8_t VL53L4CD_RdWord(Dev_t dev, uint16_t RegisterAdress, uint16_t *value)
{
    uint8_t reg[2];
    uint8_t data[2];

    reg[0] = (uint8_t)(RegisterAdress >> 8);
    reg[1] = (uint8_t)(RegisterAdress & 0xFF);

    if(!I2C1_WriteRead(dev, reg, 2, data, 2))
        return 1;

    I2C_WaitDone();

    if(I2C1_ErrorGet() != I2C_ERROR_NONE)
        return 1;

    *value = ((uint16_t)data[0] << 8) | data[1];

    return 0;
}

uint8_t VL53L4CD_RdDWord(Dev_t dev, uint16_t RegisterAdress, uint32_t *value)
{
    uint8_t reg[2];
    uint8_t data[4];

    reg[0] = (uint8_t)(RegisterAdress >> 8);
    reg[1] = (uint8_t)(RegisterAdress & 0xFF);

    if(!I2C1_WriteRead(dev, reg, 2, data, 4))
        return 1;

    I2C_WaitDone();

    if(I2C1_ErrorGet() != I2C_ERROR_NONE)
        return 1;

    *value = ((uint32_t)data[0] << 24) |
             ((uint32_t)data[1] << 16) |
             ((uint32_t)data[2] << 8)  |
             data[3];

    return 0;
}

uint8_t VL53L4CD_WrByte(Dev_t dev, uint16_t RegisterAdress, uint8_t value)
{
    uint8_t data[3];

    data[0] = (uint8_t)(RegisterAdress >> 8);
    data[1] = (uint8_t)(RegisterAdress & 0xFF);
    data[2] = value;

    if(!I2C1_Write(dev, data, 3))
        return 1;

    I2C_WaitDone();

    return (I2C1_ErrorGet() == I2C_ERROR_NONE) ? 0 : 1;
}

uint8_t VL53L4CD_WrWord(Dev_t dev, uint16_t RegisterAdress, uint16_t value)
{
    uint8_t data[4];

    data[0] = (uint8_t)(RegisterAdress >> 8);
    data[1] = (uint8_t)(RegisterAdress & 0xFF);
    data[2] = (uint8_t)(value >> 8);
    data[3] = (uint8_t)(value & 0xFF);

    if(!I2C1_Write(dev, data, 4))
        return 1;

    I2C_WaitDone();

    return (I2C1_ErrorGet() == I2C_ERROR_NONE) ? 0 : 1;
}

uint8_t VL53L4CD_WrDWord(Dev_t dev, uint16_t RegisterAdress, uint32_t value)
{
    uint8_t data[6];

    data[0] = (uint8_t)(RegisterAdress >> 8);
    data[1] = (uint8_t)(RegisterAdress & 0xFF);
    data[2] = (uint8_t)((value >> 24) & 0xFF);
    data[3] = (uint8_t)((value >> 16) & 0xFF);
    data[4] = (uint8_t)((value >> 8) & 0xFF);
    data[5] = (uint8_t)(value & 0xFF);

    if(!I2C1_Write(dev, data, 6))
        return 1;

    I2C_WaitDone();

    return (I2C1_ErrorGet() == I2C_ERROR_NONE) ? 0 : 1;
}

uint8_t VL53L4CD_WaitMs(Dev_t dev, uint32_t TimeMs)
{
    (void)dev;

    while(TimeMs--)
    {
        __delay_ms(1);
    }

    return 0;
}