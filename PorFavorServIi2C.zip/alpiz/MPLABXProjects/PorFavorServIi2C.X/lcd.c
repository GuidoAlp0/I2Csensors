#include "lcd.h"
#include "mcc_generated_files/system/pins.h"

#define _XTAL_FREQ 64000000UL

static void LCD_Pulse(void)
{
    LCD_E_SetHigh();
    __delay_us(2);
    LCD_E_SetLow();
    __delay_us(50);
}

static void LCD_Write4(uint8_t nibble)
{
    LCD_D4_LAT = (nibble >> 0) & 1;
    LCD_D5_LAT = (nibble >> 1) & 1;
    LCD_D6_LAT = (nibble >> 2) & 1;
    LCD_D7_LAT = (nibble >> 3) & 1;

    LCD_Pulse();
}

static void LCD_Send(uint8_t value, uint8_t rs)
{
    if(rs)
        LCD_RS_SetHigh();
    else
        LCD_RS_SetLow();

    LCD_Write4(value >> 4);
    LCD_Write4(value & 0x0F);
}

static void LCD_Command(uint8_t cmd)
{
    LCD_Send(cmd,0);
    __delay_ms(2);
}

static void LCD_Data(uint8_t data)
{
    LCD_Send(data,1);
}

void LCD_Init(void)
{
    __delay_ms(50);

    LCD_RS_SetLow();
    LCD_E_SetLow();

    LCD_Write4(0x03);
    __delay_ms(5);

    LCD_Write4(0x03);
    __delay_ms(5);

    LCD_Write4(0x03);
    __delay_ms(5);

    LCD_Write4(0x02);

    LCD_Command(0x28);
    LCD_Command(0x0C);
    LCD_Command(0x06);
    LCD_Command(0x01);

    __delay_ms(2);
}

void LCD_Clear(void)
{
    LCD_Command(0x01);
}

void LCD_SetCursor(uint8_t row,uint8_t col)
{
    uint8_t addr;

    if(row==0)
        addr=0x80+col;
    else
        addr=0xC0+col;

    LCD_Command(addr);
}

void LCD_Print(const char *text)
{
    while(*text)
    {
        LCD_Data(*text++);
    }
}