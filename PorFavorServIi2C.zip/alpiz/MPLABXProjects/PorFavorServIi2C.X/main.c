 #define _XTAL_FREQ 64000000UL

#include "mcc_generated_files/system/system.h"
#include "VL53L4CD_api.h"
#include "lcd.h"
#include <stdio.h>
#include <stdint.h>

#define VL53_DEFAULT_ADDR      0x29
#define SENSOR_A_ADDR          0x2A
#define SENSOR_A_ADDR_8BIT     0x54
#define SENSOR_B_ADDR          0x29

static void LCD_ShowDistances(uint16_t distA, uint16_t distB)
{
    char line[17];

    LCD_Clear();

    LCD_SetCursor(0, 0);
    sprintf(line, "A:%4u mm", distA);
    LCD_Print(line);

    LCD_SetCursor(1, 0);
    sprintf(line, "B:%4u mm", distB);
    LCD_Print(line);
}

int main(void)
{
    SYSTEM_Initialize();

    VL53L4CD_Error status;
    uint8_t readyA = 0;
    uint8_t readyB = 0;

    uint16_t distA = 0;
    uint16_t distB = 0;

    VL53L4CD_ResultsData_t resultA;
    VL53L4CD_ResultsData_t resultB;

    Dev_t sensorA = SENSOR_A_ADDR;
    Dev_t sensorB = SENSOR_B_ADDR;

    printf("\r\nDUAL VL53L4CD + LCD TEST\r\n");

    LCD_Init();
    LCD_Clear();
    LCD_SetCursor(0, 0);
    LCD_Print("Starting...");
    LCD_SetCursor(1, 0);
    LCD_Print("Please wait");

    XSHUT_A_SetLow();
    XSHUT_B_SetLow();
    __delay_ms(300);

    I2C1_Initialize();
    __delay_ms(100);

    XSHUT_A_SetHigh();
    XSHUT_B_SetLow();
    __delay_ms(500);

    status = VL53L4CD_SetI2CAddress(VL53_DEFAULT_ADDR, SENSOR_A_ADDR_8BIT);
    printf("A address change status=%u\r\n", status);

    __delay_ms(300);

    XSHUT_B_SetHigh();
    __delay_ms(500);

    status = VL53L4CD_SensorInit(sensorA);
    printf("A init status=%u\r\n", status);

    status = VL53L4CD_SensorInit(sensorB);
    printf("B init status=%u\r\n", status);

    status = VL53L4CD_StartRanging(sensorA);
    printf("A start status=%u\r\n", status);

    status = VL53L4CD_StartRanging(sensorB);
    printf("B start status=%u\r\n", status);

    LCD_Clear();
    LCD_SetCursor(0, 0);
    LCD_Print("A: ---- mm");
    LCD_SetCursor(1, 0);
    LCD_Print("B: ---- mm");

    while(1)
    {
        readyA = 0;
        readyB = 0;

        VL53L4CD_CheckForDataReady(sensorA, &readyA);
        VL53L4CD_CheckForDataReady(sensorB, &readyB);

        if(readyA)
        {
            VL53L4CD_GetResult(sensorA, &resultA);
            VL53L4CD_ClearInterrupt(sensorA);

            if(resultA.range_status == 0)
                distA = resultA.distance_mm;

            printf("A: %u mm | Status: %u\r\n",
                   resultA.distance_mm,
                   resultA.range_status);
        }

        if(readyB)
        {
            VL53L4CD_GetResult(sensorB, &resultB);
            VL53L4CD_ClearInterrupt(sensorB);

            if(resultB.range_status == 0)
                distB = resultB.distance_mm;

            printf("B: %u mm | Status: %u\r\n",
                   resultB.distance_mm,
                   resultB.range_status);
        }

        LCD_ShowDistances(distA, distB);

        __delay_ms(500);
    }
}